// MIDI instructor
//
// CC 2010 Alessando Lambardi - Some rights reserved
// Released under Creative Commons license : by-nc-sa
// You are not allowed to use this code for commercial use,
// you are allowed to modify and publish this code as long as
// this header is kept in place and the new code is licensed with
// this very same license.
//

#include <stdint.h>
#include <stdlib.h>

#include <avr/eeprom.h>
#include <avr/interrupt.h>
#include <avr/io.h>
#include <avr/pgmspace.h>
#include <avr/sleep.h>
#include <avr/wdt.h>

#define FALSE 0
#define TRUE 255

#define F_CPU 16000000UL	// CPU clock in Hertz.
#define BAUD_RATE 31250		// MIDI Baud Rate

#define ROW_04_PORT	PORTC	// Output to rows 0 to 4 of LED matrix (PC0 to PC4)
#define ROW_04_DDR 	DDRC
#define ROW_57_PORT	PORTB	// Output to rows 5 to 7 of LED matrix (PB3 to PB5)
#define ROW_57_DDR 	DDRB

#define PB_PORT		PORTB	// Pushbutton to change MIDI channel
#define PB_PORTIN	PINB
#define	PB		PB0

#define SR_DDR		DDRB	// BU2090 Shift Register to drive the rows of LED matrix
#define SR_PORT		PORTB
#define SR_DIN		PB2
#define SR_CLK		PB1

#define LED_DDR		DDRD	// Front panel LED
#define LED_PORT	PORTD
#define LED		PD2

// Variables
volatile uint8_t	display_to = FALSE;
volatile uint8_t	req_MIDI_ch_chng = FALSE;
volatile uint8_t	set_ch, pb_prsd;// Flag TRUE when setting MIDI channel number, pb pressed
volatile uint8_t	notes[12];	// 88 bits to hold the status of 88 piano keys + 8 padding bits
volatile uint8_t	MIDI_channel;	// MIDI channel to respond to
volatile uint8_t	curr_row;	// current row to be displayed
volatile uint8_t	MIDI_msg[4];	// status, data1, data2, + new msg flag
volatile uint16_t	clear_disp_to;	// time counter

volatile uint16_t	pb_dbounceL;	// Pushbutton pressed debounce
volatile uint16_t	pb_dbounceH;	// Pushbutton released debounce
volatile uint16_t	pb_rel;		// Pushbutton released counter

volatile uint8_t	pb_rel_to;	// Pushbutton released timeout flag
volatile uint8_t	pb_pressed;
volatile uint8_t	pb_was_pressed;

enum midi_msg_bytes {status_Byte = 0, data_Byte1 = 1, data_Byte2 = 2, new_msg = 3, idle = 4};
enum midi_msg_bytes msg_byte;

//functions declaration
void setup(void);
void wr_one(void);
void wr_zero(void);
void wr_one_tr(void);
void wr_zero_tr(void);
void display_row(void);
void set_note (uint8_t);
void clear_note (uint8_t);
void clear_all_notes(void);
void do_pushbutton(void);

ISR(TIMER0_COMPA_vect){
	// turn off LED matrix
	PORTC &= ~(_BV(PC0) | _BV(PC1) | _BV(PC2) | _BV(PC3) | _BV(PC4));
	PORTB &= ~(_BV(PB3) | _BV(PB4) | _BV(PB5));

	display_to = TRUE;
}

ISR(TIMER0_OVF_vect){
	uint8_t		pot_value;

	// turn on LED matrix
	switch(curr_row){
		case 0:
			PORTC |= _BV(PC0);
			break;
		case 1:
			PORTC |= _BV(PC1);
			break;
		case 2:
			PORTC |= _BV(PC2);
			break;
		case 3:
			PORTC |= _BV(PC3);
			break;
		case 4:
			PORTC |= _BV(PC4);
			break;
		case 5:
			PORTB |= _BV(PB3);
			break;
		case 6:
			PORTB |= _BV(PB4);
			break;
		case 7:
			PORTB |= _BV(PB5);
			break;
	}
	clear_disp_to++;
	pot_value = ADCH;		// set LED matrix light intensity
	OCR0A = 16 + 128 - (pot_value>>1);	// range 64-192

	// Set/reset pushbutton pressed flag after debounce period (1/10s)
	// If button pressed, resets also timer counter to return from
	// MIDI channel display/set to normal mode
	if(bit_is_clear(PB_PORTIN,PB)){
		if(pb_dbounceL < 0xFFFF) {
			pb_dbounceL++;	// Pushbutton pressed debounce
		}
		if(pb_dbounceL > (uint16_t)(F_CPU/64/256/20)) {
			pb_pressed = TRUE;  // 1/20 s debounce
		}
		pb_dbounceH = 0;	// Pushbutton released debounce

		pb_rel = 0;		// Reset 3s timer conter to return to normal mode

	} else {
		if(pb_dbounceH < 0xFFFF) {
			pb_dbounceH++;	// Pushbutton released debounce
		}
		if(pb_dbounceH > (uint16_t)(F_CPU/64/256/20)) {
			pb_pressed = FALSE; // 1/20 s debounce
		}
		pb_dbounceL = 0;

		if(pb_rel < 0xFFFF) {
			pb_rel++;	// MIDI channel display timeout
		}
		if(pb_rel > (uint16_t)3*(F_CPU/64/256)) {
			pb_rel_to = TRUE;	// 3s timeout before return from MIDI
		}				// channel display mode to normal
	}

}

ISR(USART_RX_vect){
  uint8_t chr_in;

  chr_in = UDR0;	// read serial data
  if((chr_in & 0x80) == 0x80){
  	if((chr_in & 0x0F) == MIDI_channel){
	  	MIDI_msg[status_Byte] = chr_in;	// Start filling in MIDI message table (3 bytes total)
		msg_byte = status_Byte;
	} else {
		msg_byte = idle;	// Status byte for some other channel
	}
  } else if(msg_byte == status_Byte){
  	MIDI_msg[data_Byte1] = chr_in;	// Continue filling in MIDI message table (3 bytes total)
	msg_byte = data_Byte1;
  } else if(msg_byte == data_Byte1){
  	MIDI_msg[data_Byte2] = chr_in;	// Continue filling in MIDI message table (3 bytes total)
	msg_byte = status_Byte;		// This implements MIDI running status
	MIDI_msg[new_msg] = TRUE;	// New message to be parsed
  }
  clear_disp_to = 0;	// clear watchdog counter to clear led matrix
}

void setup(void){
  SR_DDR |= _BV(SR_CLK) | _BV(SR_DIN);	// Outputs to Shift Register

  PB_PORT |= _BV(PB);			// Pull up to push button input

  LED_DDR |= _BV(LED);			// The LED on front panel

  ROW_04_DDR |= 0x1F;			// Output to LED matrix
  ROW_57_DDR |= 0xE0;			// Output to LED matrix

  TCCR0A = _BV(WGM00) | _BV(WGM01);	// Fast PWM mode 3
  TCCR0B = _BV(CS01) | _BV(CS00);	// Prescaler = 64
  OCR0A = 128;
  TIMSK0 = _BV(TOIE0) | _BV(OCIE0A);	// En Interrupts on OC1A match and Overflow

  UCSR0A = _BV(U2X0);			// Reduce Baud prescaler by two
  UCSR0B = _BV(RXCIE0) | _BV(RXEN0);	// Serial input port (enable interrupt,Enable RX, 8 bits)
  UCSR0C = _BV(UCSZ01) | _BV(UCSZ00);	// 8 bits, no parity, 1 Stop bit
  UBRR0 = (F_CPU/8L/BAUD_RATE - 1);	// Baud rate register value (0-4095)
  UBRR0H = UBRR0/256L;			// Set MIDI Baud rate to 31250
  UBRR0L = UBRR0%256L;

  ADMUX  = _BV(REFS0) | _BV(ADLAR) | _BV(MUX2) | _BV(MUX0);
  ADCSRA = _BV(ADEN) | _BV(ADSC) | _BV(ADATE) | _BV(ADPS2) | _BV(ADPS1) | _BV(ADPS0);
  ADCSRB = 0;
  DIDR0  = _BV(ADC5D);

  LED_PORT |= _BV(LED);			// Turn off front panel LED

  MIDI_msg[new_msg] = FALSE;
  MIDI_channel = 0;
  req_MIDI_ch_chng = FALSE;

  pb_pressed = FALSE;
  pb_was_pressed = FALSE;

  clear_disp_to = 0;			// timeout counter to clear LED matrix after no message
  notes[11] = 0;			// Will never change : padding bits for clean display
  					// because 12 bits*8 rows == 8 bits * 12 bytes
  sei();				// Enable interrupts
}

// The following functions handle display stuff (data shifting and digit forming)
void wr_one(){ // write a bit 1 to the shift register but no transfer yet
  SR_PORT |= _BV(SR_DIN);
  SR_PORT |= _BV(SR_CLK);
  SR_PORT &= ~_BV(SR_DIN);
  SR_PORT &= ~_BV(SR_CLK);  // Din == 0 => no transfer (BU2090)
}
void wr_zero(){ // write a bit 0 to the shift register but no transfer yet
  SR_PORT &= ~_BV(SR_DIN);
  SR_PORT |= _BV(SR_CLK);
  SR_PORT &= ~_BV(SR_CLK);  // Din == 0 => no transfer (BU2090)
}
void wr_one_tr(){ // write a bit 1 to the shift register and transfer
  SR_PORT |= _BV(SR_DIN);
  SR_PORT |= _BV(SR_CLK);
  SR_PORT &= ~_BV(SR_CLK);  // Din == 1 => transfer (BU2090)
}
void wr_zero_tr(){ // write a bit 0 to the shift register and transfer
  SR_PORT &= ~_BV(SR_DIN);
  SR_PORT |= _BV(SR_CLK);
  SR_PORT |= _BV(SR_DIN);
  SR_PORT &= ~_BV(SR_CLK);  // Din == 1 => transfer (BU2090)
}

void display_row(void){

  // row is turned on at ISR(TIMER0_OVF_vect)

  uint8_t bc;

  display_to = FALSE;
  curr_row++;
  curr_row &= 0x07;

  for(bc = 11; bc > 0; bc--){  // 11 MSBits shifted out first
	if((notes[(12*curr_row+bc)/8] & (unsigned char)1<<((12*curr_row+bc)%8)) !=0){
		wr_zero();
	}
	else{
		wr_one();
	}
  } // Last (LSB) shifted out and transferred to output
  if((notes[(12*curr_row)/8] & (unsigned char)1<<((12*curr_row)%8)) !=0){
  	wr_zero_tr();
  }
  else {
  	wr_one_tr();
  }
}

void set_note(uint8_t note){	// set/clear note in notes array
	LED_PORT &= ~_BV(LED);// Turn on front panel LED
	notes[note/8] |= 1<<(note%8);
}

void clear_note(uint8_t note){
	LED_PORT |= _BV(LED);	// Turn off front panel LED
	notes[note/8] &= ~(1<<(note%8));
}

void clear_all_notes(){
	uint8_t	idx;

	for(idx = 0;idx < 11; idx++) notes[idx] = 0;
	clear_disp_to = 0;
}

void do_pushbutton(void){

	if(pb_pressed == TRUE){ // Pushbutton pressed
		if(pb_was_pressed == FALSE){ // but previously relased
			if(req_MIDI_ch_chng == TRUE){
				clear_note(39 + MIDI_channel);
				MIDI_channel++;
				MIDI_channel &= 0x0F;
				set_note(39 + MIDI_channel);
			} else {
				UCSR0B &= ~_BV(RXCIE0);	// Disable UART RX interrupt
				clear_all_notes();
				set_note(39 + MIDI_channel);
				req_MIDI_ch_chng = TRUE;
				pb_rel_to = FALSE;
			}
			pb_was_pressed = TRUE;
			pb_rel = 0;
			clear_disp_to = 0;
		}
	} else {	// Pushbutton released
		pb_was_pressed = FALSE;
		if(req_MIDI_ch_chng == TRUE){
			if(pb_rel_to == TRUE){
				clear_note(39 + MIDI_channel);	// clear display
				MIDI_msg[new_msg] = FALSE;	// dispose of any incomplete message
				req_MIDI_ch_chng = FALSE;
				UCSR0B |= _BV(RXCIE0);		// Re-enable UART RX interrupt
			}
			clear_disp_to = 0;
		}
	}
}


int main(void) {
  uint8_t local_MIDI_msg[3], idx;	// local copy of MIDI message and index
  uint8_t note, velocity = 0;		// note and velocity to play (on/off)

  setup();
  for(;;){
  	if(MIDI_msg[new_msg] == TRUE){
		for (idx = 0; idx < 3; idx++){
			local_MIDI_msg[idx] = MIDI_msg[idx];	// copy message
		}
		MIDI_msg[new_msg] = FALSE;

		note = local_MIDI_msg[data_Byte1] - 21; // Note range is now 0 - 87
		if((local_MIDI_msg[status_Byte] & 0xF0) == 0x80){
			velocity = 0;	// note off
		}
		if((local_MIDI_msg[status_Byte] & 0xF0) == 0x90){
			velocity = local_MIDI_msg[data_Byte2];	// velocity (could be 0)
		}
		if(note < 88){
			if(velocity == 0) {
				clear_note(note);	// turn off note LED
			}
			else {
				set_note(note);		// turn on  note LED
			}
		}
	}

	if(clear_disp_to > (uint16_t)5*(F_CPU/64/256)) {
		clear_all_notes();
	}

	if(display_to == TRUE) {
		display_row();	// time to evaluate next row in LED matrix
	}

	do_pushbutton();

  }

}
